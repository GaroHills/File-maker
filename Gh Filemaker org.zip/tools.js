// Use 'var' so the dashboard can update the list in realtime without errors
var manualToolList = [
    {
        "name": "Reduce Image Size",
        "url": "reduce_image_size.html"
    },
    {
        "name": "Join Image",
        "url": "join_image.html"
    },
    {
        "name": "increase Img Size",
        "url": "increase_img_size.html"
    },
    {
        "name": "IMG TO PDF",
        "url": "img_to_pdf.html"
    },
    {
        "name": "PDF TO IMG",
        "url": "pdf_to_img.html"
    },
    {
        "name": "Photo Free Crop",
        "url": "photo_free_crop.html"
    },
    {
        "name": "JPEG_TO_PNG",
        "url": "jpeg_to_png.html"
    },
    {
        "name": "PNG_TO_JPG",
        "url": "png_to_jpg.html"
    }
    // When you paste a new tool here and save the file on your server,
    // it will appear on the dashboard automatically within 30 seconds!
];